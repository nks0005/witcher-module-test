
from distutils.core import setup

setup(
    name='witcher', version='00.00.06.20.alpha240', description="Launcher script for automated web application phuzzing",
    packages=['witcher'],
    install_requires=['tqdm','phuzzer']
)

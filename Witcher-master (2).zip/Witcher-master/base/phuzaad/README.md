# PHUZAAD - Phuzzer At A Distance

This module provides a Python wrapper for launching remote phuzzer instances. 


